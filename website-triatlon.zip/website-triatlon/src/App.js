import React, { useState } from "react";
import "./App.css";

const CategoriaEnum = {
  _10_Y_MENOS: "10 y Menos",
  _11_12: "11-12",
  _13_15: "13-15",
  NOVATOS: "Novatos",
  _16_Y_MAYORES: "16 y Mayores",
};

const RamaEnum = {
  FEMENIL: "Femenil",
  VARONIL: "Varonil",
  RELEVOS: "Relevos",
};

const DisciplinaEnum = {
  NATACION: "Natación",
  CICLISMO: "Ciclismo",
  CORREDOR: "Corredor",
  TRIATLON: "Triatlón",
};

function App() {
  const [formData, setFormData] = useState({
    fullName: "",
    birthDate: "",
    category: "",
    branch: "",
    discipline: "",
    email: "",
    photo: null,
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value,
    });
  };

  const handlePhotoChange = (e) => {
    const file = e.target.files[0];
    setFormData({
      ...formData,
      photo: file,
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
  };

  return (
    <div className="box">
      <div className="rectangle" />
      <header className="App-header">
        <form onSubmit={handleSubmit}>
          <div className="box">
            <div className="rectangle">
              <label htmlFor="encabezado">Registrar participante</label>
            </div>
          </div>

          <div className="form-group">
            <label htmlFor="fullName">Nombre: </label>
            <input
              type="text"
              name="fullName"
              value={formData.fullName}
              onChange={handleChange}
              placeholder="Escribe tu nombre completo"
              required
            />
          </div>

          <div className="form-group">
            <label htmlFor="birthDate">Fecha de nacimiento:</label>
            <input
              type="date"
              name="birthDate"
              value={formData.birthDate}
              onChange={handleChange}
              required
            />
          </div>

          <div className="form-group">
            <label htmlFor="category">Categoría:</label>
            <select
              name="category"
              value={formData.category}
              onChange={handleChange}
              required
            >
              <option value="">Selecciona una categoría</option>
              {Object.keys(CategoriaEnum).map((key) => (
                <option key={key} value={key}>
                  {CategoriaEnum[key]}
                </option>
              ))}
            </select>
          </div>

          <div className="form-group">
            <label htmlFor="branch">Rama:</label>
            <select
              name="branch"
              value={formData.branch}
              onChange={handleChange}
              required
            >
              <option value="">Selecciona una rama</option>
              {Object.keys(RamaEnum).map((key) => (
                <option key={key} value={key}>
                  {RamaEnum[key]}
                </option>
              ))}
            </select>
          </div>

          <div className="form-group">
            <label htmlFor="discipline">Disciplina:</label>
            <select
              name="discipline"
              value={formData.discipline}
              onChange={handleChange}
              required
            >
              <option value="">Selecciona una disciplina</option>
              {Object.keys(DisciplinaEnum).map((key) => (
                <option key={key} value={key}>
                  {DisciplinaEnum[key]}
                </option>
              ))}
            </select>
          </div>

          <div className="form-group">
            <label htmlFor="email">Correo electrónico:</label>
            <input
              type="email"
              name="email"
              value={formData.email}
              onChange={handleChange}
              placeholder="Correo electrónico"
              required
            />
          </div>

          <div className="form-group">
            <label htmlFor="photo">Foto:</label>
            <input
              type="file"
              name="photo"
              accept="image/*"
              onChange={handlePhotoChange}
            />
            {formData.photo && (
              <img
                src={URL.createObjectURL(formData.photo)}
                alt="Vista previa de la foto"
                className="img-preview"
              />
            )}
          </div>

          <button type="submit">Registrar</button>
          <button type="back">Regresar al inicio</button>
        </form>
      </header>
    </div>
  );
}

export default App;
