import React from "react";
import "./style.css";

export const RegistrarWeb = () => {
  return (
    <div className="registrar-web">
      <div className="div">
        <div className="overlap">
          <div className="overlap-group">
            <div className="campos">
              <div className="group">
                <div className="fondo" />
                <div className="text-wrapper">Nombre completo</div>
              </div>
              <div className="group-2">
                <div className="fondo-2" />
                <div className="text-wrapper-2">Fecha de nacimiento</div>
              </div>
              <div className="group-3">
                <div className="fondo-3" />
                <div className="text-wrapper-3">Categoría</div>
              </div>
              <div className="group-4">
                <div className="fondo-4" />
                <div className="text-wrapper-4">Rama</div>
              </div>
              <div className="group-5">
                <div className="fondo-4" />
                <div className="text-wrapper-4">Disciplina</div>
              </div>
              <div className="group-6">
                <div className="fondo-4" />
                <div className="text-wrapper-4">Correo electronico</div>
              </div>
            </div>
            <div className="logo">
              <div className="overlap-2">
                <div className="text-wrapper-5">Subir imagen</div>
                <img className="imagen" alt="Imagen" src="imagen.png" />
              </div>
            </div>
            <img className="vector" alt="Vector" src="vector-3.svg" />
            <img className="img" alt="Vector" src="vector-4.svg" />
            <img className="vector-2" alt="Vector" src="vector-5.svg" />
            <img className="image" alt="Image" src="image-14.png" />
          </div>
          <div className="menu-superior">
            <div className="overlap-group-2">
              <div className="rectangle" />
              <div className="text-wrapper-6">Registrar participante</div>
            </div>
          </div>
          <div className="b-registrar">
            <div className="div-wrapper">
              <div className="text-wrapper-7">Registrar</div>
            </div>
          </div>
        </div>
        <div className="b-back">
          <img className="image-2" alt="Image" src="image-8.png" />
        </div>
      </div>
    </div>
  );
};
import React from "react";
import "./style.css";

export const RegistrarWeb = () => {
  return (
    <div className="registrar-web">
      <div className="div">
        <div className="overlap">
          <div className="overlap-group">
            <div className="campos">
              <div className="group">
                <div className="fondo" />
                <div className="text-wrapper">Nombre completo</div>
              </div>
              <div className="group-2">
                <div className="fondo-2" />
                <div className="text-wrapper-2">Fecha de nacimiento</div>
              </div>
              <div className="group-3">
                <div className="fondo-3" />
                <div className="text-wrapper-3">Categoría</div>
              </div>
              <div className="group-4">
                <div className="fondo-4" />
                <div className="text-wrapper-4">Rama</div>
              </div>
              <div className="group-5">
                <div className="fondo-4" />
                <div className="text-wrapper-4">Disciplina</div>
              </div>
              <div className="group-6">
                <div className="fondo-4" />
                <div className="text-wrapper-4">Correo electronico</div>
              </div>
            </div>
            <div className="logo">
              <div className="overlap-2">
                <div className="text-wrapper-5">Subir imagen</div>
                <img className="imagen" alt="Imagen" src="imagen.png" />
              </div>
            </div>
            <img className="vector" alt="Vector" src="vector-3.svg" />
            <img className="img" alt="Vector" src="vector-4.svg" />
            <img className="vector-2" alt="Vector" src="vector-5.svg" />
            <img className="image" alt="Image" src="image-14.png" />
          </div>
          <div className="menu-superior">
            <div className="overlap-group-2">
              <div className="rectangle" />
              <div className="text-wrapper-6">Registrar participante</div>
            </div>
          </div>
          <div className="b-registrar">
            <div className="div-wrapper">
              <div className="text-wrapper-7">Registrar</div>
            </div>
          </div>
        </div>
        <div className="b-back">
          <img className="image-2" alt="Image" src="image-8.png" />
        </div>
      </div>
    </div>
  );
};
